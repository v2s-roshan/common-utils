from setuptools import setup
setup(name="v2s_common_utils",
      version="1.0.0",
      description="This is package used for django restframework",
      long_description="",
      author="Vishwajeet Kale",
      packages=['v2s_common_utils'],
      install_requires=['djangorestframework', 'drf-yasg'])
